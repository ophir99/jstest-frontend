import Creditcard from "./Creditcard";
export default interface Appstate {
  creditCards: Creditcard[];
  error: string;
}

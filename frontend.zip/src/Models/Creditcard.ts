export default interface CreditCard {
  name?: string;
  number?: string;
  limit?: string;
  balance: string;
}
